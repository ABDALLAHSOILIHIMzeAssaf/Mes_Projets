<?php
require_once('header.html');
require_once("fonctions.php");
$lesSalaries = getLesSalaries();
$nb_Salaries = nbSalaries();
$salaire_moyen = salaireMoyen();
$salaire_max = salariesMax();
$salaire_moyen = salariesMin();
$nb_SalariesService = nbSalariesService();

?>

<div class="container my-5">

  <a href="ajoutSalarie.html" class="btn btn-success float-end" >
    + Ajouter contact
  </a>

  <table class="table table-hover">
    <th>id</th>
    <th>nom</th>
    <th>prenom</th>
    <th>date-naissance</th>
    <th>date-embauche</th>
    <th>salaire</th>
    <th>service</th>
    <th>Modifier</th>
    <th>Supprimer</th>
    <?php foreach ($lesSalaries as $leSalarie): ?>
      <tr>
        <td><?= htmlspecialchars($leSalarie['id']); ?></td>
        <td><?= htmlspecialchars($leSalarie['nom']); ?></td>
        <td><?= htmlspecialchars($leSalarie['prenom']); ?></td>
        <td><?= htmlspecialchars($leSalarie['date_naissance']); ?></td>
        <td><?= htmlspecialchars($leSalarie['date_embauche']); ?></td>
        <td><?= htmlspecialchars($leSalarie['salaire']); ?></td>
        <td><?= htmlspecialchars($leSalarie['service']); ?></td>
        <td>
          <button class="btn btn-primary">
            <a href="modifierForm.php?id=<?= $leSalarie['id']; ?>" style="color: white; list-style: none;">Update</a>
          </button>
        </td>
        <td>
          <button class="btn btn-danger">
            <a href=".php?id=<?= $suppression['id']; ?>" style="color: white; list-style: none;">Supprimer</a>
          </button>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>

  <p>Nombre salariés : <?= $nb_Salaries;?></p>
  <p>Nombre moyen : <?= $salaire_moyen;?></p>
  <p>Salaire maximum : <?= $salaire_max;?></p>
  <p>Salaire minimum : <?= $salaire_moyen;?></p>
  <p>Nombre de services : <?= $nb_SalariesService;?></p>

</div>

<?php
require_once('footer.html');


?>