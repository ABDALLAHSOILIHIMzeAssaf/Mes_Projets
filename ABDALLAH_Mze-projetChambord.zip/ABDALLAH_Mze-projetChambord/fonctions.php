<?php
require_once("connexion.php");
function getLesSalaries()
{
    try {
        /*Sélectionne toutes les valeurs dans la table contact*/
        global $conn;
        $sql = "SELECT * FROM salaries";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        /*Retourne un tableau associatif pour chaque entrée de notre table
         *avec le nom des colonnes sélectionnées en clefs*/
        $resultat = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $resultat;
    } catch (PDOException $e) {
        echo "Erreur : " . $e->getMessage();
    }
}

# Le nombre de salariés
function nbSalaries () {
  try {
        /*Sélectionne toutes les valeurs dans la table contact*/
        global $conn;
        $sql = "SELECT COUNT(*) as nb FROM `salaries`;";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        /*Retourne un tableau associatif pour chaque entrée de notre table
         *avec le nom des colonnes sélectionnées en clefs*/
        $resultat = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultat['nb'];
    } 
    catch (PDOException $e) {
        echo "Erreur : " . $e->getMessage();
    }
}

# Le salaire moyen
function salaireMoyen () {
  try {
        /*Sélectionne toutes les valeurs dans la table contact*/
        global $conn;
        $sql = "SELECT AVG(salaire) as moyen FROM `salaries`;";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        /*Retourne un tableau associatif pour chaque entrée de notre table
         *avec le nom des colonnes sélectionnées en clefs*/
        $resultat = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultat['moyen'];
    } 
    catch (PDOException $e) {
        echo "Erreur : " . $e->getMessage();
    }
}

# Retourne le salaire maximum
function salariesMax () {
  try {
        /*Sélectionne toutes les valeurs dans la table contact*/
        global $conn;
        $sql = "SELECT MAX(salaire) as salmax FROM `salaries`;";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        /*Retourne un tableau associatif pour chaque entrée de notre table
         *avec le nom des colonnes sélectionnées en clefs*/
        $resultat = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultat['salmax'];
    } 
    catch (PDOException $e) {
        echo "Erreur : " . $e->getMessage();
    }
}

# Retourne le salaire minimum
function salariesMin () {
  try {
        /*Sélectionne toutes les valeurs dans la table contact*/
        global $conn;
        $sql = "SELECT MIN(salaire) as salmin FROM `salaries`;";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        /*Retourne un tableau associatif pour chaque entrée de notre table
         *avec le nom des colonnes sélectionnées en clefs*/
        $resultat = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultat['salmin'];
    } 
    catch (PDOException $e) {
        echo "Erreur : " . $e->getMessage();
    }
}
 
# Le nombre de salariés par service
function nbSalariesService () {
  try {
        /*Sélectionne toutes les valeurs dans la table contact*/
        global $conn;
        $sql = "SELECT service, count(*) as NbService from salaries GROUP BY service;";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        /*Retourne un tableau associatif pour chaque entrée de notre table
         *avec le nom des colonnes sélectionnées en clefs*/
        $resultat = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultat['NbService'];
    } 
    catch (PDOException $e) {
        echo "Erreur : " . $e->getMessage();
    }
}






?>