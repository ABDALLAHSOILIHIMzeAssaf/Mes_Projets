<?php
require_once('header.html');
?>



<div class="container">
    <br>
    <hr>
    <?php

    $nom = $_GET['name'];
    $prenom = $_GET['surname'];
    $date_embauche = $_GET['date_embauche'];
    $naissance = $_GET['naissance'];
    $salaire = $_GET['salaire'];
    $service = $_GET['service'];


    require_once("connexion.php");

    try {
        $sql = "INSERT INTO `salaries` (nom,prenom,date_embauche,date_naissance,salaire,service) VALUES
        ('$nom','$prenom','$date_embauche', '$naissance',$salaire,'$service')";

        $conn->exec($sql);
        header('Location: listeSalaries.php');
    } catch (PDOException $e) {
        echo "Erreur : " . $e->getMessage();
    }
    ?>


    <?php
    require_once('footer.html');
    ?>