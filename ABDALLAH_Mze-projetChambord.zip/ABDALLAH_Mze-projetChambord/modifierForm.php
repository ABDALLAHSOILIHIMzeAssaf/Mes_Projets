<?php
require_once('header.html');;

?>

  <?php

  $id = $_GET['id'];

  	  $servername = 'localhost';
      $username = 'mze';
      $password = 'mze';
      $dbname = "chambord";
            
     //On essaie de se connecter
      try{
          $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
          //On définit le mode d'erreur de PDO sur Exception
          $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
          //echo 'Connexion réussie';
      }
            
    /*On capture les exceptions si une exception est lancée et on affiche
    *les informations relatives à celle-ci*/
    catch(PDOException $e){
         echo "Erreur : " . $e->getMessage();
    }


  try {
    /*Sélectionne toutes les valeurs dans la table contact*/
    $sql = "SELECT * FROM salaries where id = $id";
    $stmt = $conn->query($sql);

    /*Retourne un tableau associatif pour chaque entrée de notre table
     *avec le nom des colonnes sélectionnées en clefs*/
    $lesalarie = $stmt->fetch(PDO::FETCH_ASSOC);

    //print_r($leContact);
  
  } catch (PDOException $e) {
    echo "Erreur : " . $e->getMessage();
  }
  ?>



  <!-- formulaire de contact-->
  <div class="col-md-7 my-5">
    <div class="row justify-content-center">
      <div class="col-lg-9">
        <form id="contact-form" method="get" action="modifierSalarie.php" style="max-width: 500px" class="mx-auto">
          <h2 class="mb-3">Contactez Nous</h2>
          <div class="row g-3">

            <div class="col-md-6">
              <label for="name" class="form-label">Nom</label>

              <input type="hidden" name="id" value="<?= $lesalarie['id']; ?>" required />

              <input type="text" value="<?= $lesalarie['nom']; ?>" class="form-control" id="name" name="name"
                required />
            </div>

            <div class="col-md-6">
              <label for="surname" class="form-label">Prénom</label>
              <input type="text" value="<?= $lesalarie['prenom']; ?>" class="form-control" id="surname" name="surname"
                required />
            </div>

            <div class="col-md-6">
              <label for="date_embauche" class="form-label">Date embauche</label>
              <input type="date" value="<?= $lesalarie['date_embauche']; ?>" class="form-control" id="date_embauche" name="date_embauche"
                required />
            </div>

            <div class="col-md-6">
              <label for="sujet" class="form-label">Date Naissance</label>
              <input type="date" value="<?= $lesalarie['date_naissance']; ?>" class="form-control" id="naissance"
                name="naissance" required />
            </div>

            <div class="col-md-6">
              <label for="salaire" class="form-label">Salaire</label>
              <input type="text" value="<?= $lesalarie['salaire']; ?>" class="form-control" id="salaire" name="salaire"
                required />
            </div>

            <div class="col-12">
              <div class="form-group">
                <label for="service">service:</label>
                <select class="form-control" id="service" name="service" required>
                  <?= $lesalarie['service']; ?>
                  <option value="Cuisine">Cuisine</option>
                  <option value="Commerciale">Commerciale</option>
                  <option value="Comptable">Comptable</option>
                  <option value="Entretient">Entretient</option>
                  <option>Autres</option>
                </select>
              </div>
            </div>
            <div class="col-12">
              <div class="row justify-content-md-end">
                <div class="col-md-6">
                  <button type="submit" class="btn btn-dark w-100 fw-bold">
                    Modifier
                  </button>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>





<?php
require_once('footer.html');
?>