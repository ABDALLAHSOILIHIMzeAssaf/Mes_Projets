<?php
require_once("connexion.php");

function supprimer ($id) {
  try {
        /*Sélectionne toutes les valeurs dans la table contact*/
        global $conn;
        $sql = "DELETE FROM `salaries` WHERE 'id'=$id";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        /*Retourne un tableau associatif pour chaque entrée de notre table
         *avec le nom des colonnes sélectionnées en clefs*/
        $resultat = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $resultat;
    } 
    catch (PDOException $e) {
        echo "Erreur : " . $e->getMessage();
    }
}
?>