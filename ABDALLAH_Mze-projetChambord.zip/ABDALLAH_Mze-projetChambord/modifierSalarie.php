<?php
require_once("connexion.php");

$id = $_GET['id'];
$nom = $_GET['name'];
$prenom = $_GET['surname'];
$date_embauche = $_GET['date_embauche'];
$naissance = $_GET['naissance'];
$salaire = $_GET['salaire'];
$service = $_GET['service'];

var_dump($id = $_GET['id']);
var_dump($nom = $_GET['name']);
var_dump($prenom = $_GET['surname']);
var_dump($date_embauche = $_GET['date_embauche']);
var_dump($naissance = $_GET['naissance']);
var_dump($salaire = $_GET['salaire']);
var_dump($service = $_GET['service']);


try {
        /*Sélectionne toutes les valeurs dans la table contact*/
        global $conn;
        $sql = "UPDATE `salaries` SET `nom`='$nom',`prenom`= '$prenom',`date_naissance` = '$naissance',`date_embauche` = '$date_embauche',`salaire` = $salaire,`service` = '$service'  WHERE id = $id";
        echo $sql ."<br>";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        /*Retourne un tableau associatif pour chaque entrée de notre table
         *avec le nom des colonnes sélectionnées en clefs*/
        $resultat = $stmt->fetchAll(PDO::FETCH_ASSOC);
        header('Location: listeSalaries.php');

        
    } 
    catch (PDOException $e) {
        echo "Erreur : " . $e->getMessage();
    }
/* `date_naissance` = $naissance,`date_embauche` = $date_embauche */
?>


