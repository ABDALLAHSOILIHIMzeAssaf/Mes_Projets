<?php
$servername = 'localhost';
$username = 'mze';
$password = 'mze';
$dbname = "chambord";

//On essaie de se connecter
try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    //On définit le mode d'erreur de PDO sur Exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

}

/*On capture les exceptions si une exception est lancée et on affiche
 *les informations relatives à celle-ci*/ catch (PDOException $e) {
    echo "Erreur : " . $e->getMessage();
}

try {
    /*Sélectionne toutes les valeurs dans la table salaries*/
    $sql = "SELECT * FROM salaries";
    $stmt = $conn->prepare($sql);
    $stmt->execute();

    /*Retourne un tableau associatif pour chaque entrée de notre table
     *avec le nom des colonnes sélectionnées en clefs*/
    $lesSalaries = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Erreur : " . $e->getMessage();
}


?>